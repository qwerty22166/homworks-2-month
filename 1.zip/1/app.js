let animal = prompt("Выберите животное Cow, Dog, Cat, Ship, Horse, Hen");

if(animal == "Cow" ) {
    console.log("Cow, 4.5years old, brown");
} else if(animal == "Dog" ) {
    console.log("Dog, 2years old, black");
} else if(animal == "Cat" ) {
    console.log("Cat, 3years old, white-red");
} else if(animal == "Ship") {
    console.log("Ship, 7years old, grey");
} else if(animal == "Horse") {
    console.log("Horse, 17years old, brown");
} else if(animal == "Hen") {
    console.log("Hen, 1.5years old, orange");
} else{
    console.log("такого варианта нет")
}